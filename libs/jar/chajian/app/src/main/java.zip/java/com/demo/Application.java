package com.demo;

import com.lzy.okgo.OkGo;
import com.lzy.okgo.https.HttpsUtils;
import com.lzy.okgo.model.HttpHeaders;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;

public class Application extends android.app.Application {
    @Override
    public void onCreate() {
        super.onCreate();

        //OKGO配置
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        //builder.addInterceptor(BrotliInterceptor.INSTANCE);
        builder.readTimeout(10000, TimeUnit.MILLISECONDS);
        builder.writeTimeout(10000, TimeUnit.MILLISECONDS);
        builder.connectTimeout(10000, TimeUnit.MILLISECONDS);
        //方法一：信任所有证书,不安全有风险
        HttpsUtils.SSLParams sslParams1 = HttpsUtils.getSslSocketFactory();
        builder.sslSocketFactory(sslParams1.sSLSocketFactory, HttpsUtils.UnSafeTrustManager)
                .hostnameVerifier(HttpsUtils.UnSafeHostnameVerifier);
        HttpHeaders headers = new HttpHeaders();
        headers.put("charset", "UTF-8");
        OkGo.getInstance().init(this).setOkHttpClient(builder.build())
                .setRetryCount(1)
                .addCommonHeaders(headers);

    }
}
