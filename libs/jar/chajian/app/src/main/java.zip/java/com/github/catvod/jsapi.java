package com.github.catvod;

import androidx.annotation.Keep;

import com.quickjs.android.JSMethod;

public class jsapi {

    public class test {
        @Keep
        @JSMethod
        public int add(int a, int b) {
            return a + b;
        }

    }

    public class test1 {
        @Keep
        @JSMethod
        public int add1(int a, int b) {
            return a + b;
        }

    }
}
